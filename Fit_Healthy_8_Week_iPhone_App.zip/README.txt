# Fit & Healthy — 8 Week Challenge

A self-contained, installable progressive web app for iPhone with daily habits, water/steps/sleep notes, weight and waist journal, a weight trend chart, Indian vegetarian meal plan, home workout library, profile settings, and JSON backup/restore.

## Install on iPhone
1. Upload the contents of this folder to an HTTPS static host (for example, a static website host).
2. Open the hosted `index.html` in Safari on your iPhone.
3. Tap Share → Add to Home Screen → Add.
4. Launch Fit & Healthy from the Home Screen.

The iOS Home Screen installation and offline caching require HTTPS (localhost is the development exception). The ZIP itself is a source package and cannot be installed by tapping it.

## Privacy
Entries are stored in browser localStorage on the device. They are not sent to a server. Use Export backup regularly. Clearing Safari website data may erase saved entries.

## Health note
This is general wellness education, not individual medical care. A 12 kg loss in eight weeks is aggressive; a gradual pace is safer for most adults. Pregnancy, breastfeeding, postpartum pelvic-floor symptoms, medical conditions or medication may require personalised advice. The workout demonstrations are text/emoji illustrations, not video instruction.
